# Shopping_List
<a href="https://codeclimate.com/github/codeclimate/codeclimate"><img src="https://codeclimate.com/github/codeclimate/codeclimate/badges/gpa.svg" /></a>
<a href="https://codeclimate.com/github/codeclimate/codeclimate/coverage"><img src="https://codeclimate.com/github/codeclimate/codeclimate/badges/coverage.svg" /></a>
<a href="https://codeclimate.com/github/codeclimate/codeclimate"><img src="https://codeclimate.com/github/codeclimate/codeclimate/badges/issue_count.svg" /></a>

The shopping app application is an application created to help users and everyday people keep track of the shopping items.
In this application we created just the basic functionalities like create, Read, Update, and Delete. 
A user can also Add items to a specific shopping list. He/she can as well view the item details, update and also delete the item.
We are mainly implementing this application using non persistent data. This means data is lost as soon as the application is shut down or stops running. 
PLease review the committed changes in the branches.


FEATURES

Users create accounts
Users can log in
Users create, view, update and delete shopping lists.
Users can add, update, view or delete items in a shopping list
